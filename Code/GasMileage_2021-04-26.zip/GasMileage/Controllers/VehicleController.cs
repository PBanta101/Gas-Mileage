﻿using GasMileage.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace GasMileage.Controllers
{
   public class VehicleController
      : Controller
   {
      //   F i e l d s   &   P r o p e r t i e s

      private IVehicleRepository _repository;


      //   C o n s t r u c t o r s

      public VehicleController(IVehicleRepository repository)
      {
         _repository = repository;
      }


      //   M e t h o d s

      //   C r e a t e

      [HttpGet]
      public IActionResult Add()
      {
         return View();
      }

      [HttpPost]
      public IActionResult Add(Vehicle v)
      {
         if (ModelState.IsValid)
         {
            _repository.Create(v);
            return RedirectToAction("Details", new { id = v.Id });
         }

         return View(v);
      }


      //   R e a d

      public IActionResult Index()
      {
         IQueryable<Vehicle> vehicles = _repository.GetAllVehicles();
         return View(vehicles);
      }

      // Read a Vehicle out of the Database and display it on a web page.
      public IActionResult Details(int id)
      {
         Vehicle v = _repository.GetVehicleById(id);
         return View(v);
      }


      //   U p d a t e

      [HttpGet]
      public IActionResult Edit(int id)
      {
         Vehicle v = _repository.GetVehicleById(id);
         return View(v);
      }

      [HttpPost]
      public IActionResult Edit(Vehicle v)
      {
         if (ModelState.IsValid)
         {
            _repository.Update(v);
            return RedirectToAction("Details", new { id = v.Id });
         }

         return View(v);
      }


      //   D e l e t e

      [HttpGet]
      public IActionResult Delete(int id)
      {
         Vehicle v = _repository.GetVehicleById(id);
         return View(v);
      }

      [HttpPost]
      public IActionResult Delete(Vehicle v)
      {
         _repository.Delete(v.Id);
         return RedirectToAction("Index");
      }

   }
}
