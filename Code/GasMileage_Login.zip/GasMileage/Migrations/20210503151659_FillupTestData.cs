﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace GasMileage.Migrations
{
    public partial class FillupTestData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "TripOdometer",
                schema: "Mpg",
                table: "Fillup",
                type: "decimal(7,1)",
                nullable: false,
                oldClrType: typeof(float),
                oldType: "real");

            migrationBuilder.AlterColumn<decimal>(
                name: "TotalCost",
                schema: "Mpg",
                table: "Fillup",
                type: "decimal(7,2)",
                nullable: false,
                oldClrType: typeof(float),
                oldType: "real");

            migrationBuilder.AlterColumn<decimal>(
                name: "Gallons",
                schema: "Mpg",
                table: "Fillup",
                type: "decimal(7,3)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.InsertData(
                schema: "Mpg",
                table: "Fillup",
                columns: new[] { "Id", "Date", "DaysSinceLastFillup", "Gallons", "Odometer", "TotalCost", "TripOdometer", "VehicleId" },
                values: new object[] { 1, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, 10.234m, 12345, 25.52m, 275.6m, 1 });

            migrationBuilder.InsertData(
                schema: "Mpg",
                table: "Fillup",
                columns: new[] { "Id", "Date", "DaysSinceLastFillup", "Gallons", "Odometer", "TotalCost", "TripOdometer", "VehicleId" },
                values: new object[] { 2, new DateTime(2021, 5, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, 10.234m, 12700, 25.52m, 275.6m, 1 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "Mpg",
                table: "Fillup",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                schema: "Mpg",
                table: "Fillup",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.AlterColumn<float>(
                name: "TripOdometer",
                schema: "Mpg",
                table: "Fillup",
                type: "real",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(7,1)");

            migrationBuilder.AlterColumn<float>(
                name: "TotalCost",
                schema: "Mpg",
                table: "Fillup",
                type: "real",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(7,2)");

            migrationBuilder.AlterColumn<int>(
                name: "Gallons",
                schema: "Mpg",
                table: "Fillup",
                type: "int",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(7,3)");
        }
    }
}
