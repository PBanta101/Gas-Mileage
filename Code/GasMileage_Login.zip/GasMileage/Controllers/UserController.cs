﻿using GasMileage.Models;
using Microsoft.AspNetCore.Mvc;

namespace GasMileage.Controllers
{
   public class UserController
      : Controller
   {
      //   F i e l d s   &   P r o p e r t i e s

      private IUserRepository _repository;


      //   C o n s t r u c t o r s

      public UserController(IUserRepository repository)
      {
         _repository = repository;
      }


      //   M e t h o d s

      //   C r e a t e

      [HttpGet]
      public IActionResult Register()
      {
         return View();
      }

      [HttpPost]
      public IActionResult Register(UserRegistrationViewModel urvm)
      {
         if (ModelState.IsValid)
         {
            User u = new User();
            u.IsAdmin = false;
            u.Password = urvm.Password;
            u.UserName = urvm.UserName;
            User newUser = _repository.Create(u);
            if (newUser == null)
            {
               ModelState.AddModelError("", "This User Already Exists.");
               return View(urvm);
            }
            else
            {
               return RedirectToAction("Index", "Home");
            }
         }

         return View(urvm);
      }


      //   R e a d

      [HttpGet]
      public IActionResult Login()
      {
         return View();
      }

      [HttpPost]
      public IActionResult Login(User u)
      {
         bool loggedIn = _repository.Login(u);
         if (loggedIn == true)
         {
            return RedirectToAction("Index", "Home");
         }
         return View(u);
      }

      public IActionResult Logout()
      {
         _repository.Logout();
         return RedirectToAction("Index", "Home");
      }


      //   U p d a t e

      [HttpGet]
      public IActionResult ChangePassword()
      {
         return View();
      }

      [HttpPost]
      public IActionResult ChangePassword(UserChangePasswordViewModel ucpvm)
      {
         if (ModelState.IsValid)
         {
            bool success =
               _repository.ChangePassword(ucpvm.CurrentPassword, ucpvm.NewPassword);
            if (success == true)
            {
               return RedirectToAction("Index", "Home");
            }
            ModelState.AddModelError("", "Unable To Change Password");
            return View(ucpvm);
         }

         return View(ucpvm);
      }


      //   D e l e t e

   }
}
